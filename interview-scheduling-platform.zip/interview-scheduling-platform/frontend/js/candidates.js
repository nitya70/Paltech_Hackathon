
const API = "http://localhost:8080/api/candidates";

document.getElementById("candidateForm").addEventListener("submit", async function(e){

    e.preventDefault();

    const formData = new FormData();

    formData.append("name", document.getElementById("name").value);
    formData.append("email", document.getElementById("email").value);
    formData.append("role", document.getElementById("role").value);
    formData.append("status", document.getElementById("status").value);
    formData.append("pipelineStage", document.getElementById("pipelineStage").value);

    const resumeFile = document.getElementById("resume").files[0];

    if(resumeFile){
        formData.append("resume", resumeFile);
    }

    await fetch(API, {
        method: "POST",
        body: formData
    });

    alert("Candidate Added Successfully");

    document.getElementById("candidateForm").reset();

    loadCandidates();
});

async function loadCandidates(){

    const response = await fetch(API);

    const candidates = await response.json();

    let rows = "";

    candidates.forEach(candidate => {

        rows += `
            <tr>
                <td>${candidate.name || ""}</td>
                <td>${candidate.email || ""}</td>
                <td>${candidate.role || ""}</td>
                <td>${candidate.status || ""}</td>
                <td>${candidate.pipelineStage || ""}</td>
                <td>
                    ${
                        candidate.resumeUrl
                        ? `<a href="${candidate.resumeUrl}" target="_blank">View Resume</a>`
                        : "No Resume"
                    }
                </td>
            </tr>
        `;
    });

    document.getElementById("candidateTableBody").innerHTML = rows;
}

loadCandidates();
