
package com.paltech.interviewplatform.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "candidates")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Candidate {

    @Id
    private String id;

    private String name;

    private String email;

    private String role;

    private String status;

    private String pipelineStage;

    private String resumeName;

    private String resumeUrl;
}
